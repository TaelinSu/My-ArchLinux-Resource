# dotfiles

This dotfiles project is collections of different applications' configuration files on my arch linux.
